﻿using System.Text.Json.Serialization;

namespace challenge.Domain.Entities
{
    public class Visita
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public int UsuarioId { get; set; }

        [JsonIgnore]
        public Usuario? Usuario { get; set; }

        public int SinistroId { get; set; }

        [JsonIgnore]
        public Sinistro? Sinistro { get; set; }
    }
}
