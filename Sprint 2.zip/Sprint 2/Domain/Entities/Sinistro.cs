﻿namespace challenge.Domain.Entities;

public class Sinistro
{
    public int Id { get; set; }
    public string? Descricao { get; set; }
    public ICollection<Visita>? Visitas { get; set; }
}
