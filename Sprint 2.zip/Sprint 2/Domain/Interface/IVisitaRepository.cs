﻿using challenge.Domain.Entities;

namespace challenge.Domain.Interface
{
    public interface IVisitaRepository
    {
        Task<IEnumerable<Visita>> GetVisitasAsync();
        Task<Visita> GetVisitaByIdAsync(int id);
        Task AddVisitaAsync(Visita visita);
        Task UpdateVisitaAsync(Visita visita);
        Task DeleteVisitaAsync(int id);
    }
}
