﻿using challenge.Domain.Entities;

namespace challenge.Domain.Interface
{
    public interface ISinistroRepository
    {
        Task<IEnumerable<Sinistro>> GetSinistrosAsync();
        Task<Sinistro> GetSinistroByIdAsync(int id);
        Task AddSinistroAsync(Sinistro sinistro);
        Task UpdateSinistroAsync(Sinistro sinistro);
        Task DeleteSinistroAsync(int id);
    }
}
