﻿using challenge.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using System.Text.Json.Serialization; // Necessário para JsonIgnore

namespace challenge.Infrastructure.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Visita> Visitas { get; set; }
        public DbSet<Sinistro> Sinistros { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configuração para a entidade Usuario
            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.ToTable("Usuarios");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();  // Define o Id como auto-incremento
            });

            // Configuração para a entidade Visita
            modelBuilder.Entity<Visita>(entity =>
            {
                entity.ToTable("Visitas");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();  // Define o Id como auto-incremento
            });

            // Configuração para a entidade Sinistro
            modelBuilder.Entity<Sinistro>(entity =>
            {
                entity.ToTable("Sinistros");
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id).ValueGeneratedOnAdd();  // Define o Id como auto-incremento
            });
        }
    }
}


