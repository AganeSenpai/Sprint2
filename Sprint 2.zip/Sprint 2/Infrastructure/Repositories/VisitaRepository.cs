﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using challenge.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace challenge.Infrastructure.Repositories;

public class VisitaRepository : IVisitaRepository
{
    private readonly AppDbContext _context;

    public VisitaRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Visita>> GetVisitasAsync()
    {
        return await _context.Visitas.ToListAsync();
    }

    public async Task<Visita> GetVisitaByIdAsync(int id)
    {
        return await _context.Visitas.FindAsync(id);
    }

    public async Task AddVisitaAsync(Visita visita)
    {
        await _context.Visitas.AddAsync(visita);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateVisitaAsync(Visita visita)
    {
        _context.Visitas.Update(visita);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteVisitaAsync(int id)
    {
        var visita = await _context.Visitas.FindAsync(id);
        if (visita != null)
        {
            _context.Visitas.Remove(visita);
            await _context.SaveChangesAsync();
        }
    }
}
