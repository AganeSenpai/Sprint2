﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {
        private readonly IUsuarioRepository _usuarioRepository;

        public UsuariosController(IUsuarioRepository usuarioRepository)
        {
            _usuarioRepository = usuarioRepository;
        }

        // GET: api/usuarios
        [HttpGet]
        public async Task<IActionResult> GetUsuarios()
        {
            var usuarios = await _usuarioRepository.GetUsuariosAsync();
            return Ok(usuarios);
        }

        // GET: api/usuarios/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetUsuario(int id)
        {
            var usuario = await _usuarioRepository.GetUsuarioByIdAsync(id);
            if (usuario == null)
                return NotFound();

            return Ok(usuario);
        }

        // POST: api/usuarios
        [HttpPost]
        public async Task<IActionResult> AddUsuario([FromBody] Usuario usuario)
        {
            if (usuario == null)
            {
                return BadRequest("Dados do usuário não fornecidos.");
            }

            if (string.IsNullOrEmpty(usuario.Nome) || string.IsNullOrEmpty(usuario.Email))
            {
                return BadRequest("Nome e Email são obrigatórios.");
            }

            // Verifica se já existe um usuário com o mesmo e-mail (validação simples)
            var usuarioExistente = await _usuarioRepository.GetUsuariosAsync();
            if (usuarioExistente.Any(u => u.Email == usuario.Email))
            {
                return BadRequest("Já existe um usuário com este e-mail.");
            }

            await _usuarioRepository.AddUsuarioAsync(usuario);
            return CreatedAtAction(nameof(GetUsuario), new { id = usuario.Id }, usuario);
        }

        // PUT: api/usuarios/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUsuario(int id, [FromBody] Usuario usuario)
        {
            if (id != usuario.Id)
                return BadRequest();

            if (usuario == null)
            {
                return BadRequest("Dados do usuário não fornecidos.");
            }

            if (string.IsNullOrEmpty(usuario.Nome) || string.IsNullOrEmpty(usuario.Email))
            {
                return BadRequest("Nome e Email são obrigatórios.");
            }

            // Verifica se o usuário existe
            var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(id);
            if (usuarioExistente == null)
            {
                return NotFound($"Usuário com ID {id} não encontrado.");
            }

            await _usuarioRepository.UpdateUsuarioAsync(usuario);
            return NoContent();
        }

        // DELETE: api/usuarios/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUsuario(int id)
        {
            var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(id);
            if (usuarioExistente == null)
                return NotFound();

            await _usuarioRepository.DeleteUsuarioAsync(id);
            return NoContent();
        }
    }
}


