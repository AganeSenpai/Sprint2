﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VisitasController : ControllerBase
    {
        private readonly IVisitaRepository _visitaRepository;
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly ISinistroRepository _sinistroRepository;

        public VisitasController(IVisitaRepository visitaRepository, IUsuarioRepository usuarioRepository, ISinistroRepository sinistroRepository)
        {
            _visitaRepository = visitaRepository;
            _usuarioRepository = usuarioRepository;
            _sinistroRepository = sinistroRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllVisitas()
        {
            var visitas = await _visitaRepository.GetVisitasAsync();
            return Ok(visitas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetVisitaById(int id)
        {
            var visita = await _visitaRepository.GetVisitaByIdAsync(id);
            if (visita == null)
                return NotFound();

            return Ok(visita);
        }

        [HttpPost]
        public async Task<IActionResult> CreateVisita([FromBody] Visita visita)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Verificar se o Usuario existe
            var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(visita.UsuarioId);
            if (usuarioExistente == null)
            {
                return NotFound($"Usuário com ID {visita.UsuarioId} não encontrado.");
            }

            // Verificar se o Sinistro existe
            var sinistroExistente = await _sinistroRepository.GetSinistroByIdAsync(visita.SinistroId);
            if (sinistroExistente == null)
            {
                return NotFound($"Sinistro com ID {visita.SinistroId} não encontrado.");
            }

            // Criar a Visita
            await _visitaRepository.AddVisitaAsync(visita);
            return CreatedAtAction(nameof(GetVisitaById), new { id = visita.Id }, visita);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateVisita(int id, [FromBody] Visita visita)
        {
            if (id != visita.Id)
                return BadRequest();

            // Verificar se o Usuario existe
            var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(visita.UsuarioId);
            if (usuarioExistente == null)
            {
                return NotFound($"Usuário com ID {visita.UsuarioId} não encontrado.");
            }

            // Verificar se o Sinistro existe
            var sinistroExistente = await _sinistroRepository.GetSinistroByIdAsync(visita.SinistroId);
            if (sinistroExistente == null)
            {
                return NotFound($"Sinistro com ID {visita.SinistroId} não encontrado.");
            }

            // Atualizar a Visita
            await _visitaRepository.UpdateVisitaAsync(visita);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteVisita(int id)
        {
            var visita = await _visitaRepository.GetVisitaByIdAsync(id);
            if (visita == null)
                return NotFound();

            await _visitaRepository.DeleteVisitaAsync(id);
            return NoContent();
        }
    }
}

