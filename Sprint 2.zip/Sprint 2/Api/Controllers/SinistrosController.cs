﻿using challenge.Domain.Entities;
using challenge.Domain.Interface;
using Microsoft.AspNetCore.Mvc;

namespace challenge.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SinistrosController : ControllerBase
    {
        private readonly ISinistroRepository _sinistroRepository;
        private readonly IUsuarioRepository _usuarioRepository; // Repositório de Usuário

        public SinistrosController(ISinistroRepository sinistroRepository, IUsuarioRepository usuarioRepository)
        {
            _sinistroRepository = sinistroRepository;
            _usuarioRepository = usuarioRepository;  // Adicionado para lidar com o usuário
        }

        [HttpGet]
        public async Task<IActionResult> GetAllSinistros()
        {
            var sinistros = await _sinistroRepository.GetSinistrosAsync();
            return Ok(sinistros);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetSinistroById(int id)
        {
            var sinistro = await _sinistroRepository.GetSinistroByIdAsync(id);
            if (sinistro == null)
                return NotFound();

            return Ok(sinistro);
        }

        [HttpPost]
        public async Task<IActionResult> CreateSinistro([FromBody] Sinistro sinistro)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Verificar se o Usuário existe, caso contrário criar um novo
            if (sinistro.Visitas != null)
            {
                foreach (var visita in sinistro.Visitas)
                {
                    if (visita.Usuario != null)
                    {
                        // Verificar se o usuário já existe
                        var usuarioExistente = await _usuarioRepository.GetUsuarioByIdAsync(visita.Usuario.Id);

                        if (usuarioExistente == null)
                        {
                            // Se o usuário não existir, criar um novo
                            await _usuarioRepository.AddUsuarioAsync(visita.Usuario);
                        }
                        else
                        {
                            visita.UsuarioId = usuarioExistente.Id;  // Associar o ID do usuário existente
                        }
                    }
                }
            }

            // Criar e salvar o sinistro
            await _sinistroRepository.AddSinistroAsync(sinistro);
            return CreatedAtAction(nameof(GetSinistroById), new { id = sinistro.Id }, sinistro);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateSinistro(int id, [FromBody] Sinistro sinistro)
        {
            if (id != sinistro.Id)
                return BadRequest();

            await _sinistroRepository.UpdateSinistroAsync(sinistro);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSinistro(int id)
        {
            var sinistro = await _sinistroRepository.GetSinistroByIdAsync(id);
            if (sinistro == null)
                return NotFound();

            await _sinistroRepository.DeleteSinistroAsync(id);
            return NoContent();
        }
    }
}
