using Microsoft.EntityFrameworkCore;
using challenge.Infrastructure.Data;
using challenge.Infrastructure.Repositories;
using challenge.Domain.Interface;
using challenge.Api;

var builder = WebApplication.CreateBuilder(args);

// Configura��o do banco de dados Oracle
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("DefaultConnection")));

// Inje��o de depend�ncia dos reposit�rios
builder.Services.AddScoped<IUsuarioRepository, UsuarioRepository>();
builder.Services.AddScoped<IVisitaRepository, VisitaRepository>();
builder.Services.AddScoped<ISinistroRepository, SinistroRepository>();

// Adicionar os controladores (API) com configura��o para lidar com ciclos de refer�ncia
builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.Preserve;
});

// Configurar Swagger para documenta��o da API
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Adicionar CORS com pol�tica personalizada
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAnyOrigin", policy =>
    {
        policy.AllowAnyOrigin()  // Permite qualquer origem
              .AllowAnyMethod()  // Permite qualquer m�todo HTTP
              .AllowAnyHeader(); // Permite qualquer cabe�alho
    });
});

var app = builder.Build();

// Configura��o do Swagger (dispon�vel apenas em desenvolvimento)
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(options =>
    {
        options.SwaggerEndpoint("/swagger/v1/swagger.json", "API V1");
        options.RoutePrefix = string.Empty; // Configura o Swagger para carregar na raiz (http://localhost:5152/)
    });
}

// Aplicar a pol�tica de CORS
app.UseCors("AllowAnyOrigin"); // Aplica a pol�tica de CORS que foi definida

// Configurar a aplica��o para usar controladores
app.MapControllers();

// Rodar a aplica��o
app.Run();


